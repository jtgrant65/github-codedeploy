#!/bin/bash

systemctl start httpd
