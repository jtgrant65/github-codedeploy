#!/bin/bash

systemctl stop httpd
